package fpt.com.core.view;

import javafx.scene.layout.VBox;

/**
 * BaseView
 *
 * @author senycorp
 */
abstract public class BaseView
        extends VBox {
    /**
     * Nothing to implement at this moment
     */
}
