package fpt.com.core.model;

import java.util.ArrayList;

/**
 * BaseModelList
 *
 * @author senycorp
 */
abstract public class BaseModelList<E>
        extends ArrayList<E> {
    /**
     * Nothing to implement at this moment
     */
}
