package fpt.com.problem4.component;

/**
 * Created by senycorp on 04.01.16.
 */
public class Customer {
}
